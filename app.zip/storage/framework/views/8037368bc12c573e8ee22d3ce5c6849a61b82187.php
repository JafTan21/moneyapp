<div>
    <div class="row">
        <?php echo $__env->make('inc.searchable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <table class="table mt-3">
        <thead>
            <tr>
                <td># </td>
                <td>description</td>
                <td>unit of works</td>
                <td>quantity of work</td>
                <td>unit rate</td>
                <td>completed quantity</td>
                <td>total amount</td>
                <td>project</td>
                <td>actions</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contracted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($editId == $contracted->id): ?>
            <tr>
                <td>
                    <?php echo e($contracted->id); ?>

                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'description']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'unit_of_works']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'quantity_of_work']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'unit_rate']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'completed_quantity','type' => 'number']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'total_amount','type' => 'number']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <select wire:model="project_id">
                        <option value="0">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = \App\Models\Project::select('id', 'name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                </td>
                <td>
                    <button class="btn  btn-success" wire:click="save(<?php echo e($contracted->id); ?>)">Save</button>
                </td>
            </tr>
            <?php else: ?>

            <tr>
                <td>
                    <?php echo e($contracted->id); ?>

                </td>
                <td>
                    <?php echo e($contracted->description); ?>

                </td>
                <td>
                    <?php echo e($contracted->unit_of_works); ?>

                </td>
                <td>
                    <?php echo e($contracted->quantity_of_work); ?>

                </td>
                <td>
                    <?php echo e($contracted->unit_rate); ?>

                </td>
                <td>
                    <?php echo e($contracted->completed_quantity); ?>

                </td>
                <td>
                    <?php echo e($contracted->total_amount); ?>

                </td>
                <td>
                    <?php echo e($contracted->project->name); ?>

                </td>
                <td>
                    <button class="btn btn-sm btn-info" wire:click="edit(<?php echo e($contracted->id); ?>)">Edit</button>
                    |
                    <button class="btn btn-sm btn-danger"
                        onclick="confirm('Are you sure?') || event.stopImmediatePropagation()"
                        wire:click="delete(<?php echo e($contracted->id); ?>)">
                        Delete
                    </button>
                </td>
            </tr>
            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <?php echo e($data->links()); ?>

</div><?php /**PATH /home/mir/Documents/MoneyApp/resources/views/livewire/contracted-form/contracted-form-history.blade.php ENDPATH**/ ?>