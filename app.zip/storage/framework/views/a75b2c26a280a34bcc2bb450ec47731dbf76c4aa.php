<div>
    <?php echo $__env->make('inc.success_error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['model' => 'of','label' => 'Date','type' => 'date']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <div class="form-group my-3">
        <p>Project</p>
        <select wire:model="project_id">
            <option value="0">-- Select --</option>
            <?php $__empty_1 = true; $__currentLoopData = \App\Models\Project::select('id', 'name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </select>
    </div>
    
    <div class="form-group my-3">
        <p>Construction Group</p>
        <select wire:model="construction_group">
            <option value="0">-- Select --</option>
            <?php $__empty_1 = true; $__currentLoopData = \App\Models\ConstructionGroup::select('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($cg->name); ?>"><?php echo e($cg->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </select>
    </div>

    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['model' => 'leader','label' => 'Leader']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['model' => 'payment','label' => 'Payment','type' => 'number']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <button class="btn btn-success" wire:click="save">
        Save
    </button>


</div><?php /**PATH /home/mitaclmm/erp.mitaconstruction.com/resources/views/livewire/sub-contractor/sub-contractor-form.blade.php ENDPATH**/ ?>