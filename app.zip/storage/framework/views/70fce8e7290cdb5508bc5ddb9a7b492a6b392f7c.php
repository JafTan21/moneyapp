<div>

    <?php echo $__env->make('inc.success_error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['model' => 'name','label' => 'Name: ']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['label' => 'Start Date: ','type' => 'date','model' => 'start']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['label' => 'End Date: ','type' => 'date','model' => 'end']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['label' => 'Sponsor: ','model' => 'sponsor']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['label' => 'Project value: ','model' => 'value']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['label' => 'Project description: ','model' => 'description']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['label' => 'Project progress: ','model' => 'progress']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['label' => 'Status: ','model' => 'status']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <button class="btn btn-success" wire:click="save">
        Save
    </button>

</div><?php /**PATH /home/mir/Documents/MoneyApp/resources/views/livewire/project/project-form.blade.php ENDPATH**/ ?>