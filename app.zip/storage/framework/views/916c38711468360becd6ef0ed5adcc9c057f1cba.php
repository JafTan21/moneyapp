<div>
    <div class="row">
        <?php echo $__env->make('inc.searchable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <table class="table mt-3">
        <thead>
            <tr>
                <td># </td>
                <td>Date</td>
                <td>Project</td>
                <td>Construction Group</td>
                <td>Leader</td>
                <td>Payment</td>
                <td>Actions</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($editId == $contract->id): ?>
            <tr>
                <td>
                    <?php echo e($contract->id); ?>

                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'of','type' => 'date']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <select wire:model="project_id">
                        <option value="0">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = \App\Models\Project::select('id', 'name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select> </td>
                <td>
                    
                    <select wire:model="construction_group">
                        <option value="0">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = \App\Models\ConstructionGroup::select('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($cg->name); ?>"><?php echo e($cg->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'leader']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'payment']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <button class="btn  btn-success" wire:click="save(<?php echo e($contract->id); ?>)">Save</button>
                </td>
            </tr>
            <?php else: ?>

            <tr>
                <td>
                    <?php echo e($contract->id); ?>

                </td>
                <td>
                    <?php echo e(Carbon\Carbon::parse($contract->of)->toDateSTring()); ?>

                </td>
                <td>
                    <?php echo e($contract->project->name); ?>

                </td>
                <td>
                    <?php echo e($contract->construction_group); ?>

                </td>
                <td>
                    <?php echo e($contract->leader); ?>

                </td>
                <td>
                    <?php echo e($contract->payment); ?>

                </td>
                <td>
                    <button class="btn btn-sm btn-info" wire:click="edit(<?php echo e($contract->id); ?>)">Edit</button>
                    |
                    <button class="btn btn-sm btn-danger"
                        onclick="confirm('Are you sure?') || event.stopImmediatePropagation()"
                        wire:click="delete(<?php echo e($contract->id); ?>)">
                        Delete
                    </button>
                </td>
            </tr>
            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <?php echo e($data->links()); ?>

</div><?php /**PATH /home/mir/Documents/MoneyApp/resources/views/livewire/sub-contractor/sub-contractor-history.blade.php ENDPATH**/ ?>