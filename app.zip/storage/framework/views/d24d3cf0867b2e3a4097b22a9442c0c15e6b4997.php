<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__('Supplier')); ?>

            </h2>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMoney">
                New record
            </button>


            <!-- Modal -->
            <div class="modal fade" id="addMoney" tabindex="-1" aria-labelledby="addMoneyLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addMoneyLabel">
                                New record
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('supplier.supplier-form')->html();
} elseif ($_instance->childHasBeenRendered('uJa90tJ')) {
    $componentId = $_instance->getRenderedChildComponentId('uJa90tJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('uJa90tJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uJa90tJ');
} else {
    $response = \Livewire\Livewire::mount('supplier.supplier-form');
    $html = $response->html();
    $_instance->logRenderedChild('uJa90tJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 overflow-scroll bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('supplier.supplier-history')->html();
} elseif ($_instance->childHasBeenRendered('hEQLzpo')) {
    $componentId = $_instance->getRenderedChildComponentId('hEQLzpo');
    $componentTag = $_instance->getRenderedChildComponentTagName('hEQLzpo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hEQLzpo');
} else {
    $response = \Livewire\Livewire::mount('supplier.supplier-history');
    $html = $response->html();
    $_instance->logRenderedChild('hEQLzpo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/mir/Documents/moneyapp/git/resources/views/supplier/index.blade.php ENDPATH**/ ?>