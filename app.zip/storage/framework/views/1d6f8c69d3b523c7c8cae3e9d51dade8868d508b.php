<div>

    <?php echo $__env->make('inc.success_error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="form-group my-3">
        <p>Project</p>
        <select wire:model="project_id">
            <option value="0">-- Select --</option>
            <?php $__empty_1 = true; $__currentLoopData = \App\Models\Project::select('id', 'name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </select>
    </div>
    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['model' => 'of','label' => 'Date: ','type' => 'date']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <div class="form-group my-3">
        <p>Material name</p>
        <select wire:model="material_name">
            <option value="0">-- Select --</option>
            <?php $__empty_1 = true; $__currentLoopData = \App\Constants\Constants::MATERIAL_NAMES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($name); ?>"><?php echo e($name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </select>
    </div>
    
    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['model' => 'quantity','label' => 'Quantity: ','type' => 'number']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['model' => 'rate','label' => 'Rate: ','type' => 'number']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <div class="form-group my-3">
        <p>Supplier</p>
        <select wire:model="supplier_id">
            <option value="0">-- Select --</option>
            <?php $__empty_1 = true; $__currentLoopData = \App\Models\Supplier::select('id', 'contact')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->contact); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </select>
    </div>
    
    <div class="form-group my-3">
        <p>Unit</p>
        <select wire:model="unit">
            <option value="0">-- Select --</option>
            <?php $__empty_1 = true; $__currentLoopData = \App\Constants\Constants::$units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($unit_); ?>"><?php echo e($unit_); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </select>
    </div>

    <button class="btn btn-success" wire:click="save">
        Save
    </button>

</div><?php /**PATH /home/mitaclmm/erp.mitaconstruction.com/resources/views/livewire/material/material-form.blade.php ENDPATH**/ ?>