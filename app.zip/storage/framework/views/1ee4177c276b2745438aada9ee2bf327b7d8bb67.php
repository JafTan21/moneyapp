<div class="mt-4">
    <b>Project Task</b>

    <div class="row">
        <div class="col-md-4">
            <span>start date</span>
            <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'new_start_date','type' => 'date']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <div class="col-md-4">
            <span>end date</span>
            <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'new_end_date','type' => 'date']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <div class="col-md-4">
            <span>name</span>
            <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'new_name']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4 d-flex flex-col">
            <span>project</span>
            <select wire:model="new_project_id">
                <option value="0">-- Select Project --</option>
                <?php $__empty_1 = true; $__currentLoopData = \App\Models\Project::select('id', 'name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
        </div>
        <div class="col-md-4">
            <span>progress rate</span>
            <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'new_progress_rate']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <div class="col-md-4 d-flex flex-col">
            <span>status</span>
            <select wire:model="new_status">
                <option value="0">-- Select Status --</option>
                <?php $__empty_1 = true; $__currentLoopData = \App\Models\ProjectTask::Statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($status); ?>"><?php echo e($status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
        </div>
        <div class="row mt-3">
            <div class="col-md-4">
                <button class="btn btn-success" wire:click="save_new()">Save</button>
            </div>
        </div>
    </div>



    <table class="table mt-3">

        <thead>
            <tr>
                <td>#</td>
                <td>Start Date</td>
                <td>End Date</td>
                <td>Name</td>
                <td>Project</td>
                <td>Progress rate</td>
                <td>status</td>
                <td>Actions</td>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($edit_id == $task->id): ?>
            <tr>
                <td>
                    <?php echo e($task->id); ?>

                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'start_date','type' => 'date']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'end_date','type' => 'date']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'name']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <select wire:model="project_id">
                        <option value="0">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = \App\Models\Project::select('id', 'name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'progress_rate']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <select wire:model="status">
                        <option value="0">-- Select Status --</option>
                        <?php $__empty_1 = true; $__currentLoopData = \App\Models\ProjectTask::Statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($status); ?>"><?php echo e($status); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                </td>
                <td>
                    <button class="btn btn-success" wire:click="save()">Save</button>
                </td>
            </tr>
            <?php else: ?>
            <tr>
                <td>
                    <?php echo e($task->id); ?>

                </td>
                <td>
                    <?php echo e(Carbon\Carbon::parse($task->start_date)->toDateSTring()); ?>

                </td>
                <td>
                    <?php echo e(Carbon\Carbon::parse($task->end_date)->toDateSTring()); ?>

                </td>
                <td>
                    <?php echo e($task->name); ?>

                </td>
                <td>
                    <?php echo e($task->project->name); ?>

                </td>
                <td>
                    <?php echo e($task->progress_rate); ?>

                </td>
                <td>
                    <?php echo e($task->status); ?>

                </td>
                <td>
                    <button class="btn btn-info" wire:click="edit(<?php echo e($task->id); ?>)">Edit</button> |
                    <button class="btn btn-danger"
                        onclick="confirm('Are you sure?') || event.stopImmediatePropagation()"
                        wire:click="delete(<?php echo e($task->id); ?>)">Delete</button>
                </td>
            </tr>
            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH /home/mitaclmm/erp.mitaconstruction.com/resources/views/livewire/project/project-task.blade.php ENDPATH**/ ?>