<?php

namespace App\Constants;

class ConstructionGroup
{

    static $values = [
        'CIVIL',
        'STEEL',
        'ELECTRIC',
        'SANITARY',
        'PAINTING',
    ];
}