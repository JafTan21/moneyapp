<svg x-show="!isSidebarOpen" aria-hidden="true" class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
</svg><?php /**PATH /home/mir/Documents/moneyapp/git/storage/framework/views/6d2866256902fc9703bab11043bd7d3bb70425a5.blade.php ENDPATH**/ ?>