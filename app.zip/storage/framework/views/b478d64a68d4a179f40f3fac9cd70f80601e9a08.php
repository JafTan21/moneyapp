<div class="p-6 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    Project
                </div>
                <div class="card-body">
                    <select wire:model="project_id">
                        <option value="0">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = \App\Models\Project::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project_): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($project_->id); ?>"><?php echo e($project_->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
        </div>
        <?php if($project): ?>
        <div class="col-md-3">
            <p>Project cost: <?php echo e($project->value); ?> bdt</p>
            <p>Project Expense: <?php echo e($project->monies()->sum('out')); ?> bdt</p>
            <p>Project Deposit: <?php echo e($project->monies()->sum('in')); ?> bdt</p>
        </div>
        <div class="col-md-3">
            <p>Project duration:</p>
            <p>
                <?php if($project->start): ?>
                <?php echo e(\Carbon\Carbon::parse($project->start)->toDateString()); ?>

                <?php endif; ?>
                -
                <?php if($project->end): ?>
                <?php echo e(\Carbon\Carbon::parse($project->end)->toDateString()); ?>

                <?php endif; ?>


                <?php if($project->start && $project->end): ?>

                <br> (
                <?php echo e(\Carbon\Carbon::parse($project->start)->diffInDays(now())); ?> /
                <?php echo e(\Carbon\Carbon::parse($project->start)->diffInDays(\Carbon\Carbon::parse($project->end))); ?> days)
                <?php endif; ?>

            </p>
        </div>
        <?php endif; ?>
    </div>

    <?php if($project): ?>
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    Project Work Status
                </div>
                <div class="card-body">
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    Project Completion %
                </div>
                <div class="card-body">
                    <?php echo e($project->progress); ?>

                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    Project Stage
                </div>
                <div class="card-body">

                    <?php echo e($project->status); ?>

                </div>
            </div>
        </div>

    </div>

    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    Project Total Resource
                </div>
                <div class="card-body">
                    Total Foreman: <?php echo e($project->labors->sum('daily_foreman') ?? 0); ?> <br>
                    Total Worker: <?php echo e($project->labors->sum('daily_worker') ?? 0); ?>

                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    Todays Resource
                </div>
                <div class="card-body">
                    Daily Foreman: <?php echo e($project->todays_labors->sum('daily_foreman') ?? 0); ?> <br>
                    Daily Worker: <?php echo e($project->todays_labors->sum('daily_worker') ?? 0); ?>

                </div>
            </div>
        </div>

    </div>
    <?php endif; ?>
</div><?php /**PATH /home/mir/Documents/moneyapp/git/resources/views/livewire/project-dashboard.blade.php ENDPATH**/ ?>