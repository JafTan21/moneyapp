<div>
    <?php if($success || $error): ?>
    <?php if($success): ?>
    <div class="alert alert-success">
        <?php echo e($success); ?>

    </div>
    <?php endif; ?>

    <?php if($error): ?>
    <div class="alert alert-danger">
        <?php echo e($error); ?>

    </div>
    <?php endif; ?>
    <?php endif; ?>
</div><?php /**PATH /home/mir/Documents/moneyapp/git/resources/views/inc/success_error.blade.php ENDPATH**/ ?>