<div class="collapse show" id="ConstructorGroups">
    <table class="table">
        <thead>

            <tr>
                <td>#</td>
                <td>Name</td>
                <td>Description</td>
                <td>Action</td>
            </tr>

        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <?php if($editId == $group->id): ?>
            <tr>
                <td><?php echo e($group->id); ?></td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'name']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'description']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <button wire:click="update(<?php echo e($group->id); ?>)" class="btn btn-success">Update</button>
                </td>
            </tr>
            <?php else: ?>
            <tr>
                <td><?php echo e($group->id); ?></td>
                <td><?php echo e($group->name); ?></td>
                <td><?php echo e($group->description); ?></td>
                <td>
                    <button class="btn btn-sm btn-info" wire:click="edit(<?php echo e($group->id); ?>)">Edit</button>
                    |
                    <button class="btn btn-sm btn-danger" wire:click="delete(<?php echo e($group->id); ?>)">
                        Delete
                    </button>
                </td>
            </tr>
            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>


            <?php if($editId ==''): ?>
            <tr>
                <td></td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['model' => 'name','label' => 'Name']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\Input::class, ['model' => 'description','label' => 'Description']); ?>
<?php $component->withName('custom-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4)): ?>
<?php $component = $__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4; ?>
<?php unset($__componentOriginalc2816d92e3ee607aa8b0ba9e96d76b8f06318bf4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <div class="form-group" style="margin-top: 40px;">
                        <button wire:click="save()" class="btn btn-success" <?php echo e($name ==''?'disabled':''); ?>>
                            save
                        </button>
                    </div>
                </td>

            </tr>
            <?php endif; ?>

        </tbody>
    </table>
</div><?php /**PATH /home/mitaclmm/erp.mitaconstruction.com/resources/views/livewire/construction-group.blade.php ENDPATH**/ ?>