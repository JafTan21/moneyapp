<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="p-6 overflow-scroll bg-white rounded-md shadow-md dark:bg-dark-eval-1">
            <a data-bs-toggle="collapse" href="#ConstructorGroups" role="button" aria-expanded="false"
                aria-controls="ConstructorGroups" class="btn btn-primary">Construction groups</a>

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('construction-group')->html();
} elseif ($_instance->childHasBeenRendered('TnXacJa')) {
    $componentId = $_instance->getRenderedChildComponentId('TnXacJa');
    $componentTag = $_instance->getRenderedChildComponentTagName('TnXacJa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TnXacJa');
} else {
    $response = \Livewire\Livewire::mount('construction-group');
    $html = $response->html();
    $_instance->logRenderedChild('TnXacJa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">


            <h2 class="text-xl font-semibold leading-tight mt-3">
                <?php echo e(__('Sub Contractor')); ?>

            </h2>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMoney">
                New record
            </button>


            <!-- Modal -->
            <div class="modal fade" id="addMoney" tabindex="-1" aria-labelledby="addMoneyLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addMoneyLabel">
                                New record
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sub-contractor.sub-contractor-form')->html();
} elseif ($_instance->childHasBeenRendered('xoS9D4u')) {
    $componentId = $_instance->getRenderedChildComponentId('xoS9D4u');
    $componentTag = $_instance->getRenderedChildComponentTagName('xoS9D4u');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xoS9D4u');
} else {
    $response = \Livewire\Livewire::mount('sub-contractor.sub-contractor-form');
    $html = $response->html();
    $_instance->logRenderedChild('xoS9D4u', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 overflow-scroll bg-white rounded-md shadow-md dark:bg-dark-eval-1">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('summery.sub-contractor-summery')->html();
} elseif ($_instance->childHasBeenRendered('TZqSiPA')) {
    $componentId = $_instance->getRenderedChildComponentId('TZqSiPA');
    $componentTag = $_instance->getRenderedChildComponentTagName('TZqSiPA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TZqSiPA');
} else {
    $response = \Livewire\Livewire::mount('summery.sub-contractor-summery');
    $html = $response->html();
    $_instance->logRenderedChild('TZqSiPA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <hr>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sub-contractor.sub-contractor-history')->html();
} elseif ($_instance->childHasBeenRendered('sYwnE4J')) {
    $componentId = $_instance->getRenderedChildComponentId('sYwnE4J');
    $componentTag = $_instance->getRenderedChildComponentTagName('sYwnE4J');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sYwnE4J');
} else {
    $response = \Livewire\Livewire::mount('sub-contractor.sub-contractor-history');
    $html = $response->html();
    $_instance->logRenderedChild('sYwnE4J', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/mitaclmm/erp.mitaconstruction.com/resources/views/sub-contractor/index.blade.php ENDPATH**/ ?>