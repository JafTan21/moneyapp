<svg aria-hidden="true" class="w-6 h-6 lg:hidden" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
</svg><?php /**PATH /home/mir/Documents/moneyapp/git/storage/framework/views/0b346c888158f59bfd2b32819ac26ca969410506.blade.php ENDPATH**/ ?>