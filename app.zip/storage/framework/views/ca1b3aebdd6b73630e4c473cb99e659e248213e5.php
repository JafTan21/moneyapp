<div class="form-group my-3">
    <p><?php echo e($label); ?></p>
    <input type="<?php echo e($type); ?>" class="form-control" wire:model.lazy="<?php echo e($model); ?>">
</div><?php /**PATH /home/mitaclmm/erp.mitaconstruction.com/resources/views/components/custom/input.blade.php ENDPATH**/ ?>