<div class="p-6 bg-white rounded-md shadow-md dark:bg-dark-eval-1">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header d-flex items-center justify-between">
                    Material

                    <button class="btn btn-info text-white" wire:click="export">
                        Export
                    </button>
                </div>
                <div class="card-body">
                    <p>Project name</p>
                    <select wire:model="projectName">
                        <option value="">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($project->name); ?>"><?php echo e($project->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>

                    <p>Material name</p>
                    <select wire:model="materialName">
                        <option value="">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = $material_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($material->material_name); ?>"><?php echo e($material->material_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>

                    <p>Material group</p>
                    <select wire:model="materialGroup">
                        <option value="">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = $material_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($material->material_group); ?>"><?php echo e($material->material_group); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>

                    <p>Supplier</p>
                    <select wire:model="supplier">
                        <option value="">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($supplier->contact); ?>"><?php echo e($supplier->contact); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>


                </div>
                <div class="card-footer">
                    Total quantity: <?php echo e($total_quantity); ?>


                </div>
            </div>
        </div>

    </div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('material.material-history')->html();
} elseif ($_instance->childHasBeenRendered('l3507046675-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3507046675-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3507046675-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3507046675-0');
} else {
    $response = \Livewire\Livewire::mount('material.material-history');
    $html = $response->html();
    $_instance->logRenderedChild('l3507046675-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


</div><?php /**PATH /home/mir/Documents/moneyapp/git/resources/views/livewire/summery/material-summery.blade.php ENDPATH**/ ?>