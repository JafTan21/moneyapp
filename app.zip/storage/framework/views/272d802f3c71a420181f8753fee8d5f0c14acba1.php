<div>
    <div class="row">
        <?php echo $__env->make('inc.searchable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-md-3">
            <p>Total deposit: <?php echo e($totalDeposit); ?></p>
            <p>Total withdraw: <?php echo e($totalWithdraw); ?></p>
            <p>Total saving: <?php echo e($totalDeposit -$totalWithdraw); ?></p>
        </div>
    </div>
    <table class="table mt-3">
        <thead>
            <tr>
                <td>#</td>
                <td>Date</td>
                <td>Project</td>
                <td>Deposit</td>
                <td>Withdraw</td>
                <td>Description</td>
                <td>Actions</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $money): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($editId == $money->id): ?>
            <tr>
                <td>
                    <?php echo e($money->id); ?>

                </td>
                <td>
                    <input wire:model="of" class="form-control" type="date" />
                </td>
                <td>
                    <select wire:model="project_id">
                        <option value="0">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = \App\Models\Project::select('id', 'name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                </td>
                <td>
                    <input wire:model="in" class="form-control" type="text" />
                </td>
                <td>
                    <input wire:model="out" class="form-control" type="text" />
                </td>
                <td>
                    <input wire:model="description" class="form-control" type="text" />
                </td>
                <td>
                    <button class="btn  btn-success" wire:click="save(<?php echo e($money->id); ?>)">Save</button>
                </td>
            </tr>
            <?php else: ?>

            <tr>
                <td>
                    <?php echo e($money->id); ?>

                </td>
                <td>
                    <?php echo e(Carbon\Carbon::parse($money->of)->toDateSTring()); ?>

                </td>
                <td>
                    <?php echo e($money->project->name); ?>

                </td>
                <td>
                    <?php echo e($money->in); ?>

                </td>
                <td>
                    <?php echo e($money->out); ?>

                </td>
                <td>
                    <?php echo e($money->description); ?>

                </td>
                <td>
                    <button class="btn btn-sm btn-info" wire:click="edit(<?php echo e($money->id); ?>)">Edit</button>
                    |
                    <button class="btn btn-sm btn-danger"
                        onclick="confirm('Are you sure?') || event.stopImmediatePropagation()"
                        wire:click="delete(<?php echo e($money->id); ?>)">
                        Delete
                    </button>
                </td>
            </tr>
            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <?php echo e($data->links()); ?>

</div><?php /**PATH /home/mir/Documents/moneyapp/git/resources/views/livewire/money/money-history.blade.php ENDPATH**/ ?>