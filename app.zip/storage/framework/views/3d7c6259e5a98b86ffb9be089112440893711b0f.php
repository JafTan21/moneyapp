<div class="p-6 bg-white rounded-md shadow-md dark:bg-dark-eval-1">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Sub contractor summery
                </div>
                <div class="card-body">

                    <p>Project name</p>
                    <select wire:model="projectName">
                        <option value="">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($project->name); ?>"><?php echo e($project->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>


                    <p>Construction group</p>
                    <select wire:model="constructionGroup">
                        <option value="">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($group->name); ?>"><?php echo e($group->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="card-footer">
                    Total amount: <?php echo e($total_amount); ?>


                </div>
            </div>
        </div>

    </div>

</div><?php /**PATH /home/mitaclmm/erp.mitaconstruction.com/resources/views/livewire/summery/sub-contractor-summery.blade.php ENDPATH**/ ?>