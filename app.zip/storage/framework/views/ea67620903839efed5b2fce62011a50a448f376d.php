


<img src="<?php echo e(asset('images/logo.png')); ?>" alt="Mita Constuction Application" style="height: 90px"><?php /**PATH /home/mir/Documents/moneyapp/git/resources/views/components/application-logo.blade.php ENDPATH**/ ?>