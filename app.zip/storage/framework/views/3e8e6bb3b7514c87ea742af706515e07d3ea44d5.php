


<img src="<?php echo e(asset('images/logo.png')); ?>" alt="Mita Constuction Application" style="height: 90px"><?php /**PATH /home/mitaclmm/erp.mitaconstruction.com/resources/views/components/application-logo.blade.php ENDPATH**/ ?>