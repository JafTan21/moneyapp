<div>
    <div class="row">
        <?php echo $__env->make('inc.searchable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <table class="table mt-3">
        <thead>
            <tr>
                <td># </td>
                <td>Date</td>
                <td>Project</td>
                <td>Daily worker</td>
                <td>Daily foreman</td>
                <td>Construction Group</td>
                <td>Group Leader</td>
                <td>Daily Labor Payment</td>
                <td>Actions</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($editId == $labor->id): ?>
            <tr>
                <td>
                    <?php echo e($labor->id); ?>

                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'of','type' => 'date']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <select wire:model="project_id">
                        <option value="0">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = \App\Models\Project::select('id', 'name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'daily_worker','type' => 'number']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'daily_foreman','type' => 'number']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    
                    <select wire:model="construction_group">
                        <option value="0">-- Select --</option>
                        <?php $__empty_1 = true; $__currentLoopData = \App\Models\ConstructionGroup::select('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($cg->name); ?>"><?php echo e($cg->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'group_leader']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Custom\EditInput::class, ['model' => 'daily_labor_payment']); ?>
<?php $component->withName('edit-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584)): ?>
<?php $component = $__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584; ?>
<?php unset($__componentOriginalfeb375b3d650e88e078e75909b113f9924d22584); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </td>
                <td>
                    <button class="btn  btn-success" wire:click="save(<?php echo e($labor->id); ?>)">Save</button>
                </td>
            </tr>
            <?php else: ?>

            <tr>
                <td>
                    <?php echo e($labor->id); ?>

                </td>
                <td>
                    <?php echo e(Carbon\Carbon::parse($labor->of)->toDateSTring()); ?>

                </td>
                <td>
                    <?php echo e($labor->project->name); ?>

                </td>
                <td>
                    <?php echo e($labor->daily_worker); ?>

                </td>
                <td>
                    <?php echo e($labor->daily_foreman); ?>

                </td>
                <td>
                    <?php echo e($labor->construction_group); ?>

                </td>
                <td>
                    <?php echo e($labor->group_leader); ?>

                </td>
                <td>
                    <?php echo e($labor->daily_labor_payment); ?>

                </td>
                <td>
                    <button class="btn btn-sm btn-info" wire:click="edit(<?php echo e($labor->id); ?>)">Edit</button>
                    |
                    <button class="btn btn-sm btn-danger"
                        onclick="confirm('Are you sure?') || event.stopImmediatePropagation()"
                        wire:click="delete(<?php echo e($labor->id); ?>)">
                        Delete
                    </button>
                </td>
            </tr>
            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <?php echo e($data->links()); ?>

</div><?php /**PATH /home/mitaclmm/erp.mitaconstruction.com/resources/views/livewire/labor/labor-history.blade.php ENDPATH**/ ?>