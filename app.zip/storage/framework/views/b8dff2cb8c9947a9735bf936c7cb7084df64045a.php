<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__('Projects')); ?>

            </h2>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProject">
                add new record
            </button>


            <!-- Modal -->
            <div class="modal fade" id="addProject" tabindex="-1" aria-labelledby="addProjectLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addProjectLabel">
                                Create new
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('project.project-form')->html();
} elseif ($_instance->childHasBeenRendered('K6pPTwb')) {
    $componentId = $_instance->getRenderedChildComponentId('K6pPTwb');
    $componentTag = $_instance->getRenderedChildComponentTagName('K6pPTwb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('K6pPTwb');
} else {
    $response = \Livewire\Livewire::mount('project.project-form');
    $html = $response->html();
    $_instance->logRenderedChild('K6pPTwb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 overflow-scroll bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('project.project-history')->html();
} elseif ($_instance->childHasBeenRendered('shzSFhj')) {
    $componentId = $_instance->getRenderedChildComponentId('shzSFhj');
    $componentTag = $_instance->getRenderedChildComponentTagName('shzSFhj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('shzSFhj');
} else {
    $response = \Livewire\Livewire::mount('project.project-history');
    $html = $response->html();
    $_instance->logRenderedChild('shzSFhj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('project.project-task')->html();
} elseif ($_instance->childHasBeenRendered('A7lgGB5')) {
    $componentId = $_instance->getRenderedChildComponentId('A7lgGB5');
    $componentTag = $_instance->getRenderedChildComponentTagName('A7lgGB5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('A7lgGB5');
} else {
    $response = \Livewire\Livewire::mount('project.project-task');
    $html = $response->html();
    $_instance->logRenderedChild('A7lgGB5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/mitaclmm/erp.mitaconstruction.com/resources/views/project/index.blade.php ENDPATH**/ ?>