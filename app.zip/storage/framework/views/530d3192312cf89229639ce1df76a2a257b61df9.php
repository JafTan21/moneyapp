<div>
    <div class="col-md-4">
        <div class="form-group">
            <p>Search:</p>
            <input wire:model.debounce.1000ms="search" type="text" class="form-control">
        </div>
    </div>


    <table class="table mt-3">
        <thead>
            <tr>
                <td>#</td>
                <td>Name</td>
                <td>Email</td>
                <td>Role</td>
                <td>Permissions</td>
                <td>Actions</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td>
                    <?php echo e($user->id); ?>

                </td>
                <td>
                    <?php echo e($user->name); ?>

                </td>
                <td>
                    <?php echo e($user->email); ?>

                </td>
                <td>
                    <?php echo e($user->roles?->first()?->name); ?>

                </td>
                <td>
                    <?php if($editId == $user->id): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li>
                        <input type="checkbox" value="<?php echo e($permission->name); ?>" wire:model="checkedPermissions">
                        <?php echo e($permission->name); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                    <a wire:click="save(<?php echo e($user->id); ?>)" class="btn btn-success btn-sm">Save</a>
                    <?php else: ?>
                    <ol>
                        <?php $__empty_1 = true; $__currentLoopData = $user->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li><?php echo e($permission->name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </ol>
                    <a wire:click="edit(<?php echo e($user->id); ?>)" class="text-info">Edit</a>
                    <?php endif; ?>

                </td>

                <td>
                    <form class="d-inline" action="<?php echo e(route('delete_user')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                        <button type="submit" class="text-danger">
                            Delete
                        </button>
                    </form> |
                    <form class="d-inline" action="<?php echo e(route('login_to_user')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                        <button type="submit" class="text-info">
                            Login
                        </button>
                    </form>
                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <?php echo e($users->links()); ?>

</div><?php /**PATH /home/mir/Documents/MoneyApp/resources/views/livewire/users.blade.php ENDPATH**/ ?>