<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__('Profile')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 overflow-scroll bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <div class="row">
            <div class="col-md-5 mt-4">
                <b>Profile info</b>
                <hr>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                <form action="<?php echo e(route('update_profile')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">

                    <div class="form-group mt-3">
                        <span>Name</span>
                        <input required name="name" value="<?php echo e(auth()->user()->name); ?>" type="text" class="form-control">
                    </div>


                    <div class="form-group mt-3">
                        <span>Email</span>
                        <input required name="email" value="<?php echo e(auth()->user()->email); ?>" type="text"
                            class="form-control">
                    </div>



                    <div class="form-group mt-3">
                        <span>Password</span>
                        <input required name="password" type="password" class="form-control">
                    </div>

                    <button class="btn btn-success mt-5">Save</button>
                </form>
            </div>
            <div class="col-md-5 mt-4">
                <b>Change password</b>
                <hr>

                <?php if(Session::has('password_error')): ?>
                <ul class="mt-3 list-disc list-inside text-sm text-red-600">
                    <li><?php echo e(Session::get('password_error')); ?></li>
                </ul>
                <?php endif; ?>

                <form action="<?php echo e(route('change_password')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">

                    <div class="form-group mt-3">
                        <span>Old password</span>
                        <input required name="old_password" type="text" class="form-control">
                    </div>


                    <div class="form-group mt-3">
                        <span>New password</span>
                        <input required name="new_password" type="text" class="form-control">
                    </div>


                    <div class="form-group mt-3">
                        <span>Confirm password</span>
                        <input required name="confirm_password" type="text" class="form-control">
                    </div>

                    <button class="btn btn-success mt-5">Save</button>


                </form>

            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/mitaclmm/erp.mitaconstruction.com/resources/views/pages/profile.blade.php ENDPATH**/ ?>