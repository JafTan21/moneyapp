<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__('Contracted form')); ?>

            </h2>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMoney">
                new record
            </button>


            <!-- Modal -->
            <div class="modal fade" id="addMoney" tabindex="-1" aria-labelledby="addMoneyLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addMoneyLabel">
                                New record
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contracted-form.contracted-form-form')->html();
} elseif ($_instance->childHasBeenRendered('BHphuWm')) {
    $componentId = $_instance->getRenderedChildComponentId('BHphuWm');
    $componentTag = $_instance->getRenderedChildComponentTagName('BHphuWm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BHphuWm');
} else {
    $response = \Livewire\Livewire::mount('contracted-form.contracted-form-form');
    $html = $response->html();
    $_instance->logRenderedChild('BHphuWm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 overflow-scroll bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contracted-form.contracted-form-history')->html();
} elseif ($_instance->childHasBeenRendered('CjZIX5d')) {
    $componentId = $_instance->getRenderedChildComponentId('CjZIX5d');
    $componentTag = $_instance->getRenderedChildComponentTagName('CjZIX5d');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CjZIX5d');
} else {
    $response = \Livewire\Livewire::mount('contracted-form.contracted-form-history');
    $html = $response->html();
    $_instance->logRenderedChild('CjZIX5d', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/mitaclmm/erp.mitaconstruction.com/resources/views/contractedform/index.blade.php ENDPATH**/ ?>