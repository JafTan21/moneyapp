<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="p-6 overflow-scroll bg-white rounded-md shadow-md dark:bg-dark-eval-1">
            <a data-bs-toggle="collapse" href="#ConstructorGroups" role="button" aria-expanded="false"
                aria-controls="ConstructorGroups" class="btn btn-primary">Construction groups</a>

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('construction-group')->html();
} elseif ($_instance->childHasBeenRendered('wGedJ05')) {
    $componentId = $_instance->getRenderedChildComponentId('wGedJ05');
    $componentTag = $_instance->getRenderedChildComponentTagName('wGedJ05');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wGedJ05');
} else {
    $response = \Livewire\Livewire::mount('construction-group');
    $html = $response->html();
    $_instance->logRenderedChild('wGedJ05', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">


            <h2 class="text-xl font-semibold leading-tight mt-3">
                <?php echo e(__('Sub Contractor')); ?>

            </h2>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMoney">
                New record
            </button>


            <!-- Modal -->
            <div class="modal fade" id="addMoney" tabindex="-1" aria-labelledby="addMoneyLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addMoneyLabel">
                                New record
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sub-contractor.sub-contractor-form')->html();
} elseif ($_instance->childHasBeenRendered('dQXsiwO')) {
    $componentId = $_instance->getRenderedChildComponentId('dQXsiwO');
    $componentTag = $_instance->getRenderedChildComponentTagName('dQXsiwO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dQXsiwO');
} else {
    $response = \Livewire\Livewire::mount('sub-contractor.sub-contractor-form');
    $html = $response->html();
    $_instance->logRenderedChild('dQXsiwO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 overflow-scroll bg-white rounded-md shadow-md dark:bg-dark-eval-1">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('summery.sub-contractor-summery')->html();
} elseif ($_instance->childHasBeenRendered('iSG0XJc')) {
    $componentId = $_instance->getRenderedChildComponentId('iSG0XJc');
    $componentTag = $_instance->getRenderedChildComponentTagName('iSG0XJc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iSG0XJc');
} else {
    $response = \Livewire\Livewire::mount('summery.sub-contractor-summery');
    $html = $response->html();
    $_instance->logRenderedChild('iSG0XJc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <hr>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sub-contractor.sub-contractor-history')->html();
} elseif ($_instance->childHasBeenRendered('Z0ZlMh2')) {
    $componentId = $_instance->getRenderedChildComponentId('Z0ZlMh2');
    $componentTag = $_instance->getRenderedChildComponentTagName('Z0ZlMh2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Z0ZlMh2');
} else {
    $response = \Livewire\Livewire::mount('sub-contractor.sub-contractor-history');
    $html = $response->html();
    $_instance->logRenderedChild('Z0ZlMh2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/mir/Documents/MoneyApp/resources/views/sub-contractor/index.blade.php ENDPATH**/ ?>